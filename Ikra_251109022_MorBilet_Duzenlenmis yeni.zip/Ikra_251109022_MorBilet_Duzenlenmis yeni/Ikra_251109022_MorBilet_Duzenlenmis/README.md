# İkra Mor Bilet Satış Sitesi
## Kullanılan Teknolojiler

- Backend: Node.js + Express
- Veritabanı: MySQL
- Oturum: express-session
- Şifreleme: bcryptjs
- Frontend: HTML, CSS, JavaScript
- Hazır CSS kütüphanesi kullanılmamıştır.

## Proje Bilgileri

- Öğrenci adı: İkra
- Öğrenci numarası: 251109022
- Son hane: 2
- Tema rengi: Mor / Lila
- Konu: Etkinlik Bilet Satış Sitesi
- API ön eki: `/api/251109022`
- Veritabanı adı: `ikra_bilet`

## Kurulum

1. Proje klasöründe terminal açın.

2. Paketleri yükleyin:

```bash
npm install
```

3. MySQL üzerinde veritabanını oluşturun.

```bash
mysql -u root -p < db.sql
```

4. `.env.example` dosyasını `.env` adıyla kopyalayın.

```bash
cp .env.example .env
```

5. `.env` dosyasındaki MySQL kullanıcı adı ve şifre bilgilerini kendi bilgisayarınıza göre düzenleyin.

6. Projeyi çalıştırın.

```bash
npm start
```

7. Tarayıcıdan açın:

```text
http://localhost:3000
```

## Sayfalar

- `/index.html` Ana sayfa
- `/hakkimizda.html` Hakkımızda ve YouTube iframe alanı
- `/biletler.html` Bilet listesi ve fiyat tablosu
- `/iletisim.html` İletişim formu ve Google Harita iframe alanı
- `/kayit.html` Kullanıcı kayıt sayfası
- `/giris.html` Kullanıcı giriş sayfası
- `/admin` Girişle korunan admin paneli

## REST API Endpointleri

- `POST /api/251109022/kayit` kullanıcı kaydı
- `POST /api/251109022/giris` kullanıcı girişi
- `POST /api/251109022/cikis` çıkış
- `GET /api/251109022/biletler` bilet listeleme
- `POST /api/251109022/biletler` bilet ekleme
- `PUT /api/251109022/biletler/:id` bilet güncelleme
- `DELETE /api/251109022/biletler/:id` bilet silme
- `POST /api/251109022/mesajlar` iletişim mesajı kaydetme
- `POST /api/251109022/siparisler` bilet satın alma kaydı oluşturma

## Admin Paneline Giriş

Önce `/kayit.html` sayfasından kullanıcı oluşturun. Daha sonra `/giris.html` sayfasından giriş yapın. Giriş yaptıktan sonra `/admin` sayfasına erişebilirsiniz.