CREATE DATABASE IF NOT EXISTS ikra_bilet CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci;
USE ikra_bilet;

CREATE TABLE IF NOT EXISTS `251109022_kullanicilar` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ad_soyad VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  sifre_hash VARCHAR(255) NOT NULL,
  olusturma_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `251109022_kategoriler` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ad VARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS `251109022_biletler` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ad VARCHAR(140) NOT NULL UNIQUE,
  aciklama VARCHAR(255),
  tarih DATETIME NOT NULL,
  konum VARCHAR(140) NOT NULL,
  fiyat DECIMAL(10,2) NOT NULL,
  kontenjan INT NOT NULL DEFAULT 0,
  gorsel VARCHAR(160) DEFAULT 'images/konser.svg',
  kategori_id INT,
  olusturma_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_251109022_bilet_kategori` FOREIGN KEY (kategori_id) REFERENCES `251109022_kategoriler`(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS `251109022_mesajlar` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ad VARCHAR(80) NOT NULL,
  soyad VARCHAR(80) NOT NULL,
  email VARCHAR(120) NOT NULL,
  tercih VARCHAR(40) NOT NULL,
  konu VARCHAR(80) NOT NULL,
  mesaj TEXT NOT NULL,
  olusturma_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS `251109022_siparisler` (
  id INT AUTO_INCREMENT PRIMARY KEY,
  kullanici_id INT NOT NULL,
  bilet_id INT NOT NULL,
  adet INT NOT NULL DEFAULT 1,
  toplam_fiyat DECIMAL(10,2) NOT NULL,
  olusturma_tarihi TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_251109022_siparis_kullanici` FOREIGN KEY (kullanici_id) REFERENCES `251109022_kullanicilar`(id) ON DELETE CASCADE,
  CONSTRAINT `fk_251109022_siparis_bilet` FOREIGN KEY (bilet_id) REFERENCES `251109022_biletler`(id) ON DELETE CASCADE
);

INSERT INTO `251109022_kategoriler` (ad) VALUES
('Konser'), ('Tiyatro'), ('Festival'), ('Sinema'), ('Stand-up')
ON DUPLICATE KEY UPDATE ad = VALUES(ad);

INSERT INTO `251109022_biletler` (ad, aciklama, tarih, konum, fiyat, kontenjan, gorsel, kategori_id) VALUES
('Mor Sahne Konseri', 'Canlı müzik ve ışık gösterisi bulunan konser bileti.', '2026-06-12 20:30:00', 'İstanbul Açık Hava Sahnesi', 450.00, 120, 'images/konser.svg', 1),
('Lila Perde Tiyatro Oyunu', 'İki perdelik keyifli tiyatro gösterisi.', '2026-06-18 19:00:00', 'Kadıköy Kültür Merkezi', 280.00, 80, 'images/tiyatro.svg', 2),
('Gençlik Yaz Festivali', 'Açık alanda müzik, yemek ve etkinlik alanları.', '2026-07-04 16:00:00', 'Maltepe Etkinlik Alanı', 600.00, 200, 'images/festival.svg', 3),
('Hafta Sonu Sinema Gecesi', 'Özel gösterim ve koltuk rezervasyonu.', '2026-06-22 21:00:00', 'Moda Sinema Salonu', 190.00, 60, 'images/sinema.svg', 4),
('Gülümse Stand-up Akşamı', 'Yerel komedyenlerle eğlenceli bir akşam.', '2026-06-28 20:00:00', 'Beşiktaş Gösteri Salonu', 250.00, 75, 'images/standup.svg', 5)
ON DUPLICATE KEY UPDATE
  aciklama = VALUES(aciklama),
  tarih = VALUES(tarih),
  konum = VALUES(konum),
  fiyat = VALUES(fiyat),
  kontenjan = VALUES(kontenjan),
  gorsel = VALUES(gorsel),
  kategori_id = VALUES(kategori_id);
