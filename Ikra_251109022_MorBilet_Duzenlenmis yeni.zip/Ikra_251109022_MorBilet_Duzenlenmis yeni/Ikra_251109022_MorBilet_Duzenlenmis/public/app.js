const iOgrenciNo = "251109022";
const iApi = `/api/${iOgrenciNo}`;

function iMesajYaz(secici, mesaj){
  const alan = document.querySelector(secici);
  if(alan){ alan.textContent = mesaj; }
}

function iMetniKoru(deger){
  return String(deger ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function iParaYaz(deger){
  return Number(deger || 0).toLocaleString("tr-TR", { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + " TL";
}

function iTarihYaz(deger){
  if(!deger){ return "Tarih yok"; }
  return new Date(deger).toLocaleString("tr-TR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

async function iIstek(url, ayarlar = {}){
  const cevap = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(ayarlar.headers || {}) },
    credentials: "include",
    ...ayarlar
  });
  const veri = await cevap.json().catch(() => ({}));
  if(!cevap.ok){ throw new Error(veri.mesaj || "İşlem yapılamadı"); }
  return veri;
}

async function iBiletleriYukle(){
  const kartAlani = document.querySelector("#i-biletler-alani");
  const tabloGovdesi = document.querySelector("#i-fiyat-govdesi");
  if(!kartAlani && !tabloGovdesi){ return; }

  try{
    const veri = await iIstek(`${iApi}/biletler`);
    if(!Array.isArray(veri.biletler) || veri.biletler.length === 0){ return; }

    if(kartAlani){
      kartAlani.innerHTML = veri.biletler.map(bilet => `
        <article class="i-bilet-karti">
          <img src="${iMetniKoru(bilet.gorsel || 'images/konser.svg')}" alt="${iMetniKoru(bilet.ad)}">
          <div class="i-bilet-aciklama">
            <span class="i-kategori-etiketi">${iMetniKoru(bilet.kategori_adi || 'Etkinlik')}</span>
            <h2>${iMetniKoru(bilet.ad)}</h2>
            <p>${iMetniKoru(bilet.aciklama || 'Etkinlik bileti')}</p>
            <p><i class="fa-solid fa-calendar-days"></i> ${iTarihYaz(bilet.tarih)}</p>
            <p><i class="fa-solid fa-location-dot"></i> ${iMetniKoru(bilet.konum)}</p>
            <strong>${iParaYaz(bilet.fiyat)}</strong>
            <small>Kalan kontenjan: ${iMetniKoru(bilet.kontenjan)}</small>
            <button class="i-buton" type="button" onclick="iBiletAl(${Number(bilet.id)})">Bilet Al</button>
          </div>
        </article>
      `).join("");
    }

    if(tabloGovdesi){
      tabloGovdesi.innerHTML = veri.biletler.map(bilet => `
        <tr>
          <td>${iMetniKoru(bilet.ad)}</td>
          <td>${iMetniKoru(bilet.kategori_adi || '-')}</td>
          <td>${iTarihYaz(bilet.tarih)}</td>
          <td>${iParaYaz(bilet.fiyat)}</td>
        </tr>
      `).join("");
    }
  }catch(hata){
    console.log("Backend kapalı olabilir, sayfadaki örnek biletler gösteriliyor.", hata.message);
  }
}

async function iBiletAl(biletId){
  const adet = Number(prompt("Kaç adet bilet almak istiyorsunuz?", "1"));
  if(!adet || adet < 1){ return; }

  try{
    await iIstek(`${iApi}/siparisler`, {
      method: "POST",
      body: JSON.stringify({ bilet_id: biletId, adet })
    });
    alert("Bilet satın alma kaydı oluşturuldu.");
    iBiletleriYukle();
  }catch(hata){
    alert(hata.message + " Önce kayıt olup giriş yapmanız gerekebilir.");
  }
}

function iKayitHazirla(){
  const form = document.querySelector("#i-kayit-formu");
  if(!form){ return; }
  form.addEventListener("submit", async (olay) => {
    olay.preventDefault();
    const veri = Object.fromEntries(new FormData(form).entries());
    try{
      await iIstek(`${iApi}/kayit`, { method: "POST", body: JSON.stringify(veri) });
      iMesajYaz("#i-kayit-sonuc", "Kayıt başarılı. Giriş sayfasına yönlendiriliyorsunuz.");
      setTimeout(() => location.href = "giris.html", 900);
    }catch(hata){
      iMesajYaz("#i-kayit-sonuc", hata.message);
    }
  });
}

function iGirisHazirla(){
  const form = document.querySelector("#i-giris-formu");
  if(!form){ return; }
  form.addEventListener("submit", async (olay) => {
    olay.preventDefault();
    const veri = Object.fromEntries(new FormData(form).entries());
    try{
      await iIstek(`${iApi}/giris`, { method: "POST", body: JSON.stringify(veri) });
      iMesajYaz("#i-giris-sonuc", "Giriş başarılı. Admin paneline yönlendiriliyorsunuz.");
      setTimeout(() => location.href = "/admin", 700);
    }catch(hata){
      iMesajYaz("#i-giris-sonuc", hata.message);
    }
  });
}

function iIletisimHazirla(){
  const form = document.querySelector("#i-iletisim-formu");
  if(!form){ return; }
  form.addEventListener("submit", async (olay) => {
    olay.preventDefault();
    const veri = Object.fromEntries(new FormData(form).entries());
    try{
      await iIstek(`${iApi}/mesajlar`, { method: "POST", body: JSON.stringify(veri) });
      iMesajYaz("#i-form-sonuc", "Mesajınız veritabanına kaydedildi.");
      form.reset();
    }catch(hata){
      iMesajYaz("#i-form-sonuc", hata.message);
    }
  });
}

async function iAdminBiletleriYukle(){
  const liste = document.querySelector("#i-yonetim-bilet-listesi");
  if(!liste){ return; }
  try{
    const veri = await iIstek(`${iApi}/biletler`);
    liste.innerHTML = veri.biletler.map(bilet => `
      <tr>
        <td>${Number(bilet.id)}</td>
        <td>${iMetniKoru(bilet.ad)}</td>
        <td>${iMetniKoru(bilet.kategori_adi || '-')}</td>
        <td>${iParaYaz(bilet.fiyat)}</td>
        <td>${iMetniKoru(bilet.kontenjan)}</td>
        <td>
          <button class="i-islem-dugmesi i-duzenle-dugmesi" data-bilet="${encodeURIComponent(JSON.stringify(bilet))}">Düzenle</button>
          <button class="i-islem-dugmesi" onclick="iBiletSil(${Number(bilet.id)})">Sil</button>
        </td>
      </tr>
    `).join("");

    document.querySelectorAll(".i-duzenle-dugmesi").forEach(dugme => {
      dugme.addEventListener("click", () => {
        const bilet = JSON.parse(decodeURIComponent(dugme.dataset.bilet));
        iBiletDuzenle(bilet);
      });
    });
  }catch(hata){
    iMesajYaz("#i-yonetim-sonuc", hata.message);
  }
}

function iAdminHazirla(){
  const form = document.querySelector("#i-yonetim-bilet-formu");
  if(!form){ return; }
  iAdminBiletleriYukle();

  form.addEventListener("submit", async (olay) => {
    olay.preventDefault();
    const veri = Object.fromEntries(new FormData(form).entries());
    const id = veri.id;
    delete veri.id;
    veri.fiyat = Number(veri.fiyat);
    veri.kontenjan = Number(veri.kontenjan);
    veri.kategori_id = Number(veri.kategori_id);

    try{
      if(id){
        await iIstek(`${iApi}/biletler/${id}`, { method: "PUT", body: JSON.stringify(veri) });
        iMesajYaz("#i-yonetim-sonuc", "Bilet güncellendi.");
      }else{
        await iIstek(`${iApi}/biletler`, { method: "POST", body: JSON.stringify(veri) });
        iMesajYaz("#i-yonetim-sonuc", "Bilet eklendi.");
      }
      form.reset();
      document.querySelector("#i-bilet-id").value = "";
      iAdminBiletleriYukle();
    }catch(hata){
      iMesajYaz("#i-yonetim-sonuc", hata.message);
    }
  });

  const cikis = document.querySelector("#i-cikis-buton");
  if(cikis){
    cikis.addEventListener("click", async () => {
      await iIstek(`${iApi}/cikis`, { method: "POST", body: "{}" });
      location.href = "/giris.html";
    });
  }
}

function iBiletDuzenle(bilet){
  document.querySelector("#i-bilet-id").value = bilet.id;
  document.querySelector("#i-bilet-ad").value = bilet.ad || "";
  document.querySelector("#i-bilet-aciklama").value = bilet.aciklama || "";
  document.querySelector("#i-bilet-tarih").value = bilet.tarih ? new Date(bilet.tarih).toISOString().slice(0, 16) : "";
  document.querySelector("#i-bilet-konum").value = bilet.konum || "";
  document.querySelector("#i-bilet-fiyat").value = bilet.fiyat || "";
  document.querySelector("#i-bilet-kontenjan").value = bilet.kontenjan || "";
  document.querySelector("#i-bilet-kategori").value = bilet.kategori_id || 1;
  document.querySelector("#i-bilet-gorsel").value = bilet.gorsel || "images/konser.svg";
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function iBiletSil(id){
  if(!confirm("Bu bileti silmek istiyor musunuz?")){ return; }
  try{
    await iIstek(`${iApi}/biletler/${id}`, { method: "DELETE" });
    iMesajYaz("#i-yonetim-sonuc", "Bilet silindi.");
    iAdminBiletleriYukle();
  }catch(hata){
    iMesajYaz("#i-yonetim-sonuc", hata.message);
  }
}

iBiletleriYukle();
iKayitHazirla();
iGirisHazirla();
iIletisimHazirla();
iAdminHazirla();
