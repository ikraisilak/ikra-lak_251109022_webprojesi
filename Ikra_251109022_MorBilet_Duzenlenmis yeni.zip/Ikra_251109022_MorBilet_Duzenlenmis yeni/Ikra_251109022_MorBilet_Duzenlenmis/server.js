require("dotenv").config();
const express = require("express");
const mysql = require("mysql2/promise");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ON_EK = (process.env.OGRENCI_NO || "251109022").replace(/\D/g, "") || "251109022";

const tablolar = {
  kullanicilar: `\`${ON_EK}_kullanicilar\``,
  kategoriler: `\`${ON_EK}_kategoriler\``,
  biletler: `\`${ON_EK}_biletler\``,
  mesajlar: `\`${ON_EK}_mesajlar\``,
  siparisler: `\`${ON_EK}_siparisler\``
};

const havuz = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "ikra_bilet",
  waitForConnections: true,
  connectionLimit: 10
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Hocam burada session kullandım çünkü giriş yapan kullanıcıyı admin panelinde hatırlamam gerekiyor.
app.use(session({
  secret: process.env.SESSION_SECRET || "ikra-mor-bilet-gizli-anahtar",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: 1000 * 60 * 60 }
}));

// Hocam burada API yolundaki öğrenci numarasını kontrol ediyorum, ödevde istenen ön ek karışmasın diye.
function numaraKontrol(req, res, next){
  if(req.params.no !== ON_EK){
    return res.status(404).json({ mesaj: "API ön eki öğrenci numarasıyla eşleşmiyor." });
  }
  next();
}

// Hocam burada giriş kontrolü var; oturum yoksa kullanıcı admin sayfasına ve korumalı API'lara ulaşamıyor.
function girisGerekli(req, res, next){
  if(!req.session.kullanici){
    if(req.path.startsWith("/api/")){
      return res.status(401).json({ mesaj: "Bu işlem için önce giriş yapmalısınız." });
    }
    return res.redirect("/giris.html");
  }
  next();
}

function sayiMi(deger){
  return deger !== undefined && deger !== null && deger !== "" && !Number.isNaN(Number(deger));
}

app.get("/admin", girisGerekli, (req, res) => {
  res.sendFile(path.join(__dirname, "ozel", "admin.html"));
});

app.get("/admin.html", girisGerekli, (req, res) => {
  res.redirect("/admin");
});

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/:no/kayit", numaraKontrol, async (req, res) => {
  const { adSoyad, email, sifre } = req.body;
  if(!adSoyad || !email || !sifre){
    return res.status(400).json({ mesaj: "Tüm alanları doldurunuz." });
  }

  // Hocam şifreyi düz metin saklamadım; veritabanında daha güvenli dursun diye hashledim.
  const sifreHash = await bcrypt.hash(sifre, 10);
  try{
    // Hocam burada prepared statement kullandım, SQL injection ihtimalini azaltmak istedim.
    await havuz.execute(
      `INSERT INTO ${tablolar.kullanicilar} (ad_soyad, email, sifre_hash) VALUES (?, ?, ?)`,
      [adSoyad, email, sifreHash]
    );
    res.status(201).json({ mesaj: "Kayıt başarılı." });
  }catch(hata){
    res.status(400).json({ mesaj: "Bu email daha önce kullanılmış olabilir." });
  }
});

app.post("/api/:no/giris", numaraKontrol, async (req, res) => {
  const { email, sifre } = req.body;
  if(!email || !sifre){
    return res.status(400).json({ mesaj: "Email ve şifre gereklidir." });
  }

  // Hocam giriş yaparken email alanını kullandım çünkü kullanıcıyı tekil şekilde bulmak daha kolay oluyor.
  const [satirlar] = await havuz.execute(`SELECT * FROM ${tablolar.kullanicilar} WHERE email = ?`, [email]);
  const kullanici = satirlar[0];
  if(!kullanici){
    return res.status(401).json({ mesaj: "Email veya şifre hatalı." });
  }

  const sifreDogru = await bcrypt.compare(sifre, kullanici.sifre_hash);
  if(!sifreDogru){
    return res.status(401).json({ mesaj: "Email veya şifre hatalı." });
  }

  req.session.kullanici = { id: kullanici.id, adSoyad: kullanici.ad_soyad, email: kullanici.email };
  res.json({ mesaj: "Giriş başarılı.", kullanici: req.session.kullanici });
});

app.post("/api/:no/cikis", numaraKontrol, (req, res) => {
  // Hocam çıkışta session'ı temizliyorum, böylece admin paneli tekrar kapalı hâle geliyor.
  req.session.destroy(() => res.json({ mesaj: "Çıkış yapıldı." }));
});

app.get("/api/:no/oturum", numaraKontrol, (req, res) => {
  res.json({ kullanici: req.session.kullanici || null });
});

app.get("/api/:no/kategoriler", numaraKontrol, async (req, res) => {
  const [kategoriler] = await havuz.execute(`SELECT * FROM ${tablolar.kategoriler} ORDER BY id ASC`);
  res.json({ kategoriler });
});

app.get("/api/:no/biletler", numaraKontrol, async (req, res) => {
  // Hocam burada JOIN kullandım çünkü biletin kategori adını da tek sorguda göstermek istiyorum.
  const [biletler] = await havuz.execute(`
    SELECT b.id, b.ad, b.aciklama, b.tarih, b.konum, b.fiyat, b.kontenjan, b.gorsel, b.kategori_id, k.ad AS kategori_adi
    FROM ${tablolar.biletler} b
    LEFT JOIN ${tablolar.kategoriler} k ON b.kategori_id = k.id
    ORDER BY b.tarih ASC, b.id DESC
  `);
  res.json({ biletler });
});

app.post("/api/:no/biletler", numaraKontrol, girisGerekli, async (req, res) => {
  const { ad, aciklama, tarih, konum, fiyat, kontenjan, kategori_id, gorsel } = req.body;
  if(!ad || !tarih || !konum || !sayiMi(fiyat) || !sayiMi(kategori_id)){
    return res.status(400).json({ mesaj: "Bilet adı, tarih, konum, fiyat ve kategori zorunludur." });
  }

  // Hocam bu POST endpointi admin panelindeki formdan yeni bilet eklemek için yazıldı.
  const [sonuc] = await havuz.execute(
    `INSERT INTO ${tablolar.biletler} (ad, aciklama, tarih, konum, fiyat, kontenjan, kategori_id, gorsel) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [ad, aciklama || "", tarih, konum, fiyat, kontenjan || 0, kategori_id, gorsel || "images/konser.svg"]
  );
  res.status(201).json({ mesaj: "Bilet eklendi.", id: sonuc.insertId });
});

app.put("/api/:no/biletler/:id", numaraKontrol, girisGerekli, async (req, res) => {
  const { ad, aciklama, tarih, konum, fiyat, kontenjan, kategori_id, gorsel } = req.body;
  if(!ad || !tarih || !konum || !sayiMi(fiyat) || !sayiMi(kategori_id)){
    return res.status(400).json({ mesaj: "Güncelleme için zorunlu alanları doldurunuz." });
  }

  // Hocam PUT endpointi güncelleme şartı için var; seçilen biletin bilgilerini değiştiriyor.
  await havuz.execute(
    `UPDATE ${tablolar.biletler} SET ad = ?, aciklama = ?, tarih = ?, konum = ?, fiyat = ?, kontenjan = ?, kategori_id = ?, gorsel = COALESCE(?, gorsel) WHERE id = ?`,
    [ad, aciklama || "", tarih, konum, fiyat, kontenjan || 0, kategori_id, gorsel || null, req.params.id]
  );
  res.json({ mesaj: "Bilet güncellendi." });
});

app.delete("/api/:no/biletler/:id", numaraKontrol, girisGerekli, async (req, res) => {
  // Hocam DELETE endpointi admin panelinde bilet silme işlemi yapılabilsin diye eklendi.
  await havuz.execute(`DELETE FROM ${tablolar.biletler} WHERE id = ?`, [req.params.id]);
  res.json({ mesaj: "Bilet silindi." });
});

app.post("/api/:no/siparisler", numaraKontrol, girisGerekli, async (req, res) => {
  const { bilet_id, adet } = req.body;
  if(!sayiMi(bilet_id) || !sayiMi(adet) || Number(adet) < 1){
    return res.status(400).json({ mesaj: "Bilet ve adet bilgisi gereklidir." });
  }

  const [biletSatirlari] = await havuz.execute(`SELECT fiyat, kontenjan FROM ${tablolar.biletler} WHERE id = ?`, [bilet_id]);
  const bilet = biletSatirlari[0];
  if(!bilet){
    return res.status(404).json({ mesaj: "Bilet bulunamadı." });
  }
  if(Number(bilet.kontenjan) < Number(adet)){
    return res.status(400).json({ mesaj: "Yeterli kontenjan kalmadı." });
  }

  const toplamFiyat = Number(bilet.fiyat) * Number(adet);
  // Hocam burada satın alma mantığı için sipariş kaydı oluşturdum, böylece site gerçekten bilet satış sitesi gibi çalışıyor.
  await havuz.execute(
    `INSERT INTO ${tablolar.siparisler} (kullanici_id, bilet_id, adet, toplam_fiyat) VALUES (?, ?, ?, ?)`,
    [req.session.kullanici.id, bilet_id, adet, toplamFiyat]
  );
  await havuz.execute(`UPDATE ${tablolar.biletler} SET kontenjan = kontenjan - ? WHERE id = ?`, [adet, bilet_id]);
  res.status(201).json({ mesaj: "Bilet satın alma kaydı oluşturuldu." });
});

app.get("/api/:no/siparislerim", numaraKontrol, girisGerekli, async (req, res) => {
  const [siparisler] = await havuz.execute(`
    SELECT s.id, s.adet, s.toplam_fiyat, s.olusturma_tarihi, b.ad AS bilet_adi, b.tarih, b.konum
    FROM ${tablolar.siparisler} s
    INNER JOIN ${tablolar.biletler} b ON s.bilet_id = b.id
    WHERE s.kullanici_id = ?
    ORDER BY s.id DESC
  `, [req.session.kullanici.id]);
  res.json({ siparisler });
});

